# Flight Simulator Application

## Overview

This is a comprehensive 3D flight simulator built with React Three Fiber (R3F) and Express.js. The application features realistic aircraft physics simulation with advanced aerodynamics, multiple camera modes, and a comprehensive HUD display. Players can select from multiple aircraft types, navigate using waypoints with autopilot assistance, and practice landing approaches on a marked runway. The simulator includes dynamic weather with day/night cycles, wind effects, turbulence, and realistic stall mechanics.

## Recent Changes (November 2025)

**Aircraft Selection System:**
- Added 3 aircraft types: Fighter Jet (fast/agile), Cargo Plane (heavy/stable), Light Aircraft (balanced)
- Each aircraft has unique flight characteristics (speed, turn rate, fuel efficiency, stall speed)
- Visual differentiation with distinct 3D models and color schemes
- Selection menu accessible via Spacebar

**Advanced Physics System:**
- Air-relative velocity calculations for realistic wind effects
- Stall mechanics based on airspeed with nose-drop torque and reduced control authority
- Environmental turbulence affecting flight stability
- Wind forces that impact aircraft trajectory

**Weather and Environment:**
- Dynamic day/night cycle with transitioning sky colors and lighting
- Fog system for visibility challenges
- Layered cloud formations with memoized geometry for performance
- Time-based lighting adjustments

**Landing System:**
- Runway with visual markers and approach lights
- HUD landing guidance showing distance, glide slope deviation, and lateral offset
- 3° glide slope calculations based on ground-range distance
- Real-time alignment feedback for precision landings

**Waypoint Navigation:**
- 3D waypoint markers positioned throughout the flight area
- Autopilot mode (toggle with 'T' key) for automatic navigation
- Automatic waypoint advancement when within 30m of target
- HUD display showing active waypoint distance and autopilot status
- Autopilot disables after final waypoint is reached

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:** React with TypeScript, Vite build system, and React Three Fiber for 3D rendering

**Component Structure:**
- **3D Scene Components:** `Aircraft`, `Environment`, and `CameraController` handle the WebGL rendering layer
- **UI Components:** `HUD` displays flight telemetry; shadcn/ui component library provides reusable UI elements
- **State Management:** Zustand stores manage game state (`useGame`), flight physics (`useFlight`), and audio (`useAudio`)

**Rendering Strategy:**
- React Three Fiber wraps Three.js in declarative React components
- Custom GLSL shader support via `vite-plugin-glsl`
- Frame-by-frame physics calculations in `useFrame` hooks
- Multiple camera perspectives: cockpit view, chase camera, and external view

**Physics System:**
- Aircraft state tracks position, velocity, rotation, and angular velocity as Three.js vectors
- Real-time fuel consumption based on throttle setting
- Crash detection when altitude drops below ground level
- Keyboard-controlled flight surfaces affect aircraft orientation and momentum

**Styling:**
- Tailwind CSS with custom theme variables for consistent design
- CSS custom properties for color tokens and border radii
- Global styles prevent scrolling and ensure full-viewport canvas

### Backend Architecture

**Server Framework:** Express.js with TypeScript

**Development Setup:**
- Vite middleware in development mode for HMR (Hot Module Replacement)
- Separate production build bundling client and server code
- Request logging middleware tracks API response times and payloads

**Storage Layer:**
- Abstract `IStorage` interface defines CRUD operations for users
- In-memory `MemStorage` implementation for development
- Database schema defined with Drizzle ORM for PostgreSQL migration path
- User authentication schema prepared (username/password fields)

**API Structure:**
- Routes prefixed with `/api` for clear separation from static assets
- Route registration abstracted into `registerRoutes` function
- Error handling middleware catches and formats server errors

### Data Storage Solutions

**Database Technology:** PostgreSQL via Neon serverless platform

**ORM Choice:** Drizzle ORM for type-safe database queries
- Schema-first approach with TypeScript types inferred from tables
- Migration files generated in `./migrations` directory
- Zod integration for runtime validation of insert operations

**Schema Design:**
- Users table with serial ID, unique username, and hashed password fields
- `InsertUser` and `User` types generated from schema for type safety

**Migration Strategy:**
- `drizzle-kit push` command synchronizes schema changes to database
- Environment variable `DATABASE_URL` configures connection
- Schema defined in shared directory for client/server access

### Authentication and Authorization

**Planned Implementation:**
- User schema includes username/password fields for credential storage
- Session management prepared via `connect-pg-simple` for PostgreSQL-backed sessions
- Storage interface includes user lookup by ID and username methods
- Password hashing strategy not yet implemented (requires addition of bcrypt or similar)

### External Dependencies

**3D Graphics:**
- `three` - Core 3D rendering engine
- `@react-three/fiber` - React renderer for Three.js
- `@react-three/drei` - Helper components (KeyboardControls, etc.)
- `@react-three/postprocessing` - Visual effects pipeline

**UI Framework:**
- `@radix-ui/*` - Headless UI primitives for accessible components
- `tailwindcss` - Utility-first CSS framework
- `class-variance-authority` - Component variant management
- `lucide-react` - Icon library

**State Management:**
- `zustand` - Lightweight state management with middleware support
- `@tanstack/react-query` - Server state synchronization (prepared but not actively used)

**Database:**
- `@neondatabase/serverless` - Serverless PostgreSQL driver
- `drizzle-orm` - TypeScript ORM
- `drizzle-kit` - Schema migration tooling
- `drizzle-zod` - Runtime validation integration

**Build Tools:**
- `vite` - Fast development server and build tool
- `esbuild` - Server-side bundling
- `tsx` - TypeScript execution for development
- `@vitejs/plugin-react` - React Fast Refresh support

**Validation:**
- `zod` - Schema validation library integrated with Drizzle

**Session Management:**
- `connect-pg-simple` - PostgreSQL session store (configured but not active)

**Development:**
- `@replit/vite-plugin-runtime-error-modal` - Enhanced error display in Replit environment