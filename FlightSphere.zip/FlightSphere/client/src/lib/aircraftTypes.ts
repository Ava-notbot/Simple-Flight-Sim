export interface AircraftCharacteristics {
  name: string;
  description: string;
  maxSpeed: number;
  minSpeed: number;
  stallSpeed: number;
  pitchSpeed: number;
  rollSpeed: number;
  yawSpeed: number;
  thrust: number;
  liftCoefficient: number;
  dragCoefficient: number;
  fuelConsumptionRate: number;
  maxFuel: number;
  color: string;
  secondaryColor: string;
}

export type AircraftType = "fighter" | "cargo" | "light";

export const AIRCRAFT_TYPES: Record<AircraftType, AircraftCharacteristics> = {
  fighter: {
    name: "F-16 Fighter Jet",
    description: "Fast and agile military aircraft with high maneuverability",
    maxSpeed: 150,
    minSpeed: 40,
    stallSpeed: 35,
    pitchSpeed: 2.5,
    rollSpeed: 3.0,
    yawSpeed: 1.2,
    thrust: 80,
    liftCoefficient: 0.35,
    dragCoefficient: 0.03,
    fuelConsumptionRate: 0.8,
    maxFuel: 100,
    color: "#1e40af",
    secondaryColor: "#3b82f6",
  },
  cargo: {
    name: "C-130 Cargo Plane",
    description: "Large, stable aircraft with excellent fuel efficiency",
    maxSpeed: 80,
    minSpeed: 25,
    stallSpeed: 20,
    pitchSpeed: 0.8,
    rollSpeed: 1.0,
    yawSpeed: 0.5,
    thrust: 45,
    liftCoefficient: 0.4,
    dragCoefficient: 0.08,
    fuelConsumptionRate: 0.3,
    maxFuel: 200,
    color: "#065f46",
    secondaryColor: "#10b981",
  },
  light: {
    name: "Cessna Light Aircraft",
    description: "Small, nimble plane perfect for casual flying",
    maxSpeed: 100,
    minSpeed: 20,
    stallSpeed: 15,
    pitchSpeed: 2.0,
    rollSpeed: 2.5,
    yawSpeed: 1.0,
    thrust: 35,
    liftCoefficient: 0.38,
    dragCoefficient: 0.05,
    fuelConsumptionRate: 0.4,
    maxFuel: 120,
    color: "#991b1b",
    secondaryColor: "#ef4444",
  },
};
