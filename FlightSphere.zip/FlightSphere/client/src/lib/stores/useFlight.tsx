import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";
import * as THREE from "three";
import { AIRCRAFT_TYPES, type AircraftType } from "../aircraftTypes";

export type CameraMode = "cockpit" | "chase" | "external";

interface AircraftState {
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  rotation: THREE.Euler;
  angularVelocity: THREE.Vector3;
  throttle: number;
  fuel: number;
  crashed: boolean;
  isStalling: boolean;
}

interface EnvironmentState {
  windVelocity: THREE.Vector3;
  turbulenceIntensity: number;
  timeOfDay: number;
}

interface Waypoint {
  position: THREE.Vector3;
  name: string;
  reached: boolean;
}

interface FlightState {
  aircraft: AircraftState;
  environment: EnvironmentState;
  aircraftType: AircraftType;
  cameraMode: CameraMode;
  gameStarted: boolean;
  showAircraftSelection: boolean;
  waypoints: Waypoint[];
  activeWaypointIndex: number;
  autopilotEnabled: boolean;
  
  updateAircraft: (updates: Partial<AircraftState>) => void;
  updateEnvironment: (updates: Partial<EnvironmentState>) => void;
  setCameraMode: (mode: CameraMode) => void;
  setAircraftType: (type: AircraftType) => void;
  startGame: () => void;
  resetGame: () => void;
  consumeFuel: (amount: number) => void;
  showSelection: () => void;
  setActiveWaypoint: (index: number) => void;
  toggleAutopilot: () => void;
  markWaypointReached: (index: number) => void;
}

const getInitialAircraftState = (type: AircraftType): AircraftState => {
  const characteristics = AIRCRAFT_TYPES[type];
  return {
    position: new THREE.Vector3(0, 50, 0),
    velocity: new THREE.Vector3(0, 0, characteristics.minSpeed + 10),
    rotation: new THREE.Euler(0, 0, 0),
    angularVelocity: new THREE.Vector3(0, 0, 0),
    throttle: 0.5,
    fuel: characteristics.maxFuel,
    crashed: false,
    isStalling: false,
  };
};

const getInitialEnvironment = (): EnvironmentState => {
  return {
    windVelocity: new THREE.Vector3(
      (Math.random() - 0.5) * 10,
      0,
      (Math.random() - 0.5) * 10
    ),
    turbulenceIntensity: 0.5,
    timeOfDay: 0.5,
  };
};

export const useFlight = create<FlightState>()(
  subscribeWithSelector((set, get) => ({
    aircraft: getInitialAircraftState("fighter"),
    environment: getInitialEnvironment(),
    aircraftType: "fighter",
    cameraMode: "chase",
    gameStarted: false,
    showAircraftSelection: true,
    waypoints: [
      { position: new THREE.Vector3(200, 100, 200), name: "Waypoint Alpha", reached: false },
      { position: new THREE.Vector3(-200, 150, 300), name: "Waypoint Bravo", reached: false },
      { position: new THREE.Vector3(500, 50, -100), name: "Runway Approach", reached: false },
    ],
    activeWaypointIndex: 0,
    autopilotEnabled: false,
    
    updateAircraft: (updates) => {
      set((state) => ({
        aircraft: { ...state.aircraft, ...updates }
      }));
    },
    
    updateEnvironment: (updates) => {
      set((state) => ({
        environment: { ...state.environment, ...updates }
      }));
    },
    
    setCameraMode: (mode) => {
      set({ cameraMode: mode });
      console.log("Camera mode:", mode);
    },
    
    setAircraftType: (type) => {
      set({
        aircraftType: type,
        aircraft: getInitialAircraftState(type),
        showAircraftSelection: false,
        gameStarted: true,
      });
      console.log("Aircraft selected:", AIRCRAFT_TYPES[type].name);
    },
    
    startGame: () => {
      set({ gameStarted: true, showAircraftSelection: false });
      console.log("Flight simulator started");
    },
    
    resetGame: () => {
      const { aircraftType } = get();
      set({
        aircraft: getInitialAircraftState(aircraftType),
        cameraMode: "chase",
        gameStarted: true,
      });
      console.log("Flight simulator reset");
    },
    
    consumeFuel: (amount) => {
      set((state) => ({
        aircraft: {
          ...state.aircraft,
          fuel: Math.max(0, state.aircraft.fuel - amount)
        }
      }));
    },
    
    showSelection: () => {
      set({ showAircraftSelection: true, gameStarted: false });
      console.log("Aircraft selection shown");
    },
    
    setActiveWaypoint: (index) => {
      set({ activeWaypointIndex: index });
      console.log("Active waypoint:", index);
    },
    
    toggleAutopilot: () => {
      set((state) => ({
        autopilotEnabled: !state.autopilotEnabled
      }));
      console.log("Autopilot:", get().autopilotEnabled ? "ON" : "OFF");
    },
    
    markWaypointReached: (index) => {
      set((state) => {
        const updatedWaypoints = [...state.waypoints];
        updatedWaypoints[index] = { ...updatedWaypoints[index], reached: true };
        
        let nextIndex = index + 1;
        while (nextIndex < updatedWaypoints.length && updatedWaypoints[nextIndex].reached) {
          nextIndex++;
        }
        
        const allReached = nextIndex >= updatedWaypoints.length;
        
        return {
          waypoints: updatedWaypoints,
          activeWaypointIndex: allReached ? index : nextIndex,
          autopilotEnabled: allReached ? false : state.autopilotEnabled,
        };
      });
      console.log("Waypoint reached:", index);
    }
  }))
);
