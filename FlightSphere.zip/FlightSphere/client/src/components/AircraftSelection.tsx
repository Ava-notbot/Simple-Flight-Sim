import { useFlight } from "@/lib/stores/useFlight";
import { AIRCRAFT_TYPES, type AircraftType } from "@/lib/aircraftTypes";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";

export function AircraftSelection() {
  const { setAircraftType } = useFlight();

  const handleSelect = (type: AircraftType) => {
    setAircraftType(type);
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
      padding: '20px',
    }}>
      <h1 style={{
        fontSize: '48px',
        fontWeight: 'bold',
        color: '#ffffff',
        marginBottom: '20px',
        textShadow: '0 0 20px rgba(59, 130, 246, 0.5)',
      }}>
        3D Flight Simulator
      </h1>
      <p style={{
        fontSize: '18px',
        color: '#94a3b8',
        marginBottom: '40px',
      }}>
        Select your aircraft to begin
      </p>
      
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: '24px',
        maxWidth: '1200px',
        width: '100%',
      }}>
        {(Object.keys(AIRCRAFT_TYPES) as AircraftType[]).map((type) => {
          const aircraft = AIRCRAFT_TYPES[type];
          return (
            <Card key={type} style={{
              background: 'rgba(30, 41, 59, 0.8)',
              border: '2px solid rgba(59, 130, 246, 0.3)',
              transition: 'all 0.3s ease',
              cursor: 'pointer',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-8px)';
              e.currentTarget.style.borderColor = 'rgba(59, 130, 246, 0.8)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.borderColor = 'rgba(59, 130, 246, 0.3)';
            }}
            onClick={() => handleSelect(type)}>
              <CardHeader>
                <CardTitle style={{ color: '#ffffff', fontSize: '24px' }}>
                  {aircraft.name}
                </CardTitle>
                <CardDescription style={{ color: '#94a3b8', fontSize: '14px' }}>
                  {aircraft.description}
                </CardDescription>
              </CardHeader>
              <CardContent style={{ color: '#cbd5e1' }}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>Max Speed:</span>
                    <span style={{ fontWeight: 'bold' }}>{aircraft.maxSpeed} km/h</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>Maneuverability:</span>
                    <span style={{ fontWeight: 'bold' }}>
                      {aircraft.rollSpeed > 2 ? 'High' : aircraft.rollSpeed > 1.5 ? 'Medium' : 'Low'}
                    </span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>Fuel Capacity:</span>
                    <span style={{ fontWeight: 'bold' }}>{aircraft.maxFuel}L</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>Fuel Efficiency:</span>
                    <span style={{ fontWeight: 'bold' }}>
                      {aircraft.fuelConsumptionRate < 0.4 ? 'Excellent' : aircraft.fuelConsumptionRate < 0.6 ? 'Good' : 'Fair'}
                    </span>
                  </div>
                </div>
                <Button
                  style={{
                    width: '100%',
                    marginTop: '20px',
                    background: aircraft.color,
                    color: '#ffffff',
                    fontWeight: 'bold',
                    padding: '12px',
                    border: 'none',
                    borderRadius: '6px',
                    cursor: 'pointer',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.opacity = '0.9';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.opacity = '1';
                  }}
                >
                  Select {aircraft.name.split(' ')[0]}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
