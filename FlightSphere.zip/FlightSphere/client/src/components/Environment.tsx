import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useTexture } from "@react-three/drei";
import { useFlight } from "@/lib/stores/useFlight";
import { Runway } from "./Runway";
import { Waypoints } from "./Waypoints";

function getSkyColor(timeOfDay: number): THREE.Color {
  if (timeOfDay < 0.2) {
    return new THREE.Color().lerpColors(
      new THREE.Color("#001124"),
      new THREE.Color("#ff6b35"),
      timeOfDay / 0.2
    );
  } else if (timeOfDay < 0.3) {
    return new THREE.Color().lerpColors(
      new THREE.Color("#ff6b35"),
      new THREE.Color("#87CEEB"),
      (timeOfDay - 0.2) / 0.1
    );
  } else if (timeOfDay < 0.7) {
    return new THREE.Color("#87CEEB");
  } else if (timeOfDay < 0.8) {
    return new THREE.Color().lerpColors(
      new THREE.Color("#87CEEB"),
      new THREE.Color("#ff6b35"),
      (timeOfDay - 0.7) / 0.1
    );
  } else {
    return new THREE.Color().lerpColors(
      new THREE.Color("#ff6b35"),
      new THREE.Color("#001124"),
      (timeOfDay - 0.8) / 0.2
    );
  }
}

function getLightIntensity(timeOfDay: number): number {
  if (timeOfDay < 0.2 || timeOfDay > 0.8) {
    return 0.2;
  } else if (timeOfDay < 0.3) {
    return 0.2 + ((timeOfDay - 0.2) / 0.1) * 0.8;
  } else if (timeOfDay < 0.7) {
    return 1.0;
  } else {
    return 1.0 - ((timeOfDay - 0.7) / 0.1) * 0.8;
  }
}

function Clouds() {
  const clouds = useMemo(() => {
    const cloudData: Array<{ position: [number, number, number]; size: number }> = [];
    for (let i = 0; i < 30; i++) {
      cloudData.push({
        position: [
          (Math.random() - 0.5) * 1000,
          100 + Math.random() * 100,
          (Math.random() - 0.5) * 1000,
        ],
        size: 30 + Math.random() * 20,
      });
    }
    return cloudData;
  }, []);

  return (
    <group>
      {clouds.map((cloud, i) => (
        <mesh key={i} position={cloud.position}>
          <sphereGeometry args={[cloud.size, 8, 8]} />
          <meshStandardMaterial color="#ffffff" transparent opacity={0.7} />
        </mesh>
      ))}
    </group>
  );
}

export function Environment() {
  const { environment, updateEnvironment } = useFlight();
  const grassTexture = useTexture("/textures/grass.png");
  
  grassTexture.wrapS = grassTexture.wrapT = THREE.RepeatWrapping;
  grassTexture.repeat.set(50, 50);

  const skyGeometry = useMemo(() => {
    const geometry = new THREE.SphereGeometry(500, 32, 32);
    geometry.scale(-1, 1, 1);
    return geometry;
  }, []);

  useFrame((state, delta) => {
    const newTime = (environment.timeOfDay + delta * 0.01) % 1.0;
    updateEnvironment({ timeOfDay: newTime });
  });

  const skyColor = getSkyColor(environment.timeOfDay);
  const lightIntensity = getLightIntensity(environment.timeOfDay);
  const fogColor = skyColor.clone();

  return (
    <>
      <directionalLight
        position={[100, 100, 50]}
        intensity={lightIntensity}
        castShadow
      />
      <ambientLight intensity={0.3 + lightIntensity * 0.2} />

      <mesh receiveShadow rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
        <planeGeometry args={[2000, 2000]} />
        <meshStandardMaterial map={grassTexture} color="#3a5f2a" />
      </mesh>

      <Runway />

      <Waypoints />

      <mesh geometry={skyGeometry}>
        <meshBasicMaterial color={skyColor} side={THREE.BackSide} />
      </mesh>

      <Clouds />

      <fog attach="fog" args={[fogColor, 200, 800]} />
    </>
  );
}
