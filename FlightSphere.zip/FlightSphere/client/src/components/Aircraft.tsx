import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useFlight } from "@/lib/stores/useFlight";
import { useKeyboardControls } from "@react-three/drei";
import { AIRCRAFT_TYPES } from "@/lib/aircraftTypes";
import { FighterModel } from "./aircraft/FighterModel";
import { CargoModel } from "./aircraft/CargoModel";
import { LightModel } from "./aircraft/LightModel";

enum Controls {
  forward = 'forward',
  back = 'back',
  left = 'left',
  right = 'right',
  up = 'up',
  down = 'down',
  yawLeft = 'yawLeft',
  yawRight = 'yawRight',
  throttleUp = 'throttleUp',
  throttleDown = 'throttleDown',
  camera = 'camera',
}

export function Aircraft() {
  const meshRef = useRef<THREE.Group>(null);
  const { aircraft, environment, aircraftType, waypoints, activeWaypointIndex, autopilotEnabled, updateAircraft, consumeFuel, updateEnvironment } = useFlight();
  const [, getKeys] = useKeyboardControls<Controls>();
  const turbulenceTimer = useRef(0);

  useFrame((state, delta) => {
    if (!meshRef.current) return;

    if (aircraft.crashed) {
      return;
    }

    const characteristics = AIRCRAFT_TYPES[aircraftType];
    const controls = getKeys();
    const dt = Math.min(delta, 0.1);
    
    turbulenceTimer.current += dt;
    if (turbulenceTimer.current > 2.0) {
      turbulenceTimer.current = 0;
      updateEnvironment({
        windVelocity: new THREE.Vector3(
          (Math.random() - 0.5) * 15,
          (Math.random() - 0.5) * 3,
          (Math.random() - 0.5) * 15
        ),
      });
    }
    
    const position = aircraft.position.clone();
    const velocity = aircraft.velocity.clone();
    const rotation = aircraft.rotation.clone();
    const angularVelocity = aircraft.angularVelocity.clone();
    let throttle = aircraft.throttle;
    
    if (controls.throttleUp) {
      throttle = Math.min(1, throttle + dt * 0.5);
    }
    if (controls.throttleDown) {
      throttle = Math.max(0, throttle - dt * 0.5);
    }
    
    consumeFuel(throttle * dt * characteristics.fuelConsumptionRate);
    
    const airVelocity = velocity.clone().sub(environment.windVelocity);
    const airspeed = airVelocity.length();
    
    const isStalling = airspeed < characteristics.stallSpeed;
    
    let controlAuthority = 1.0;
    let liftMultiplier = 1.0;
    
    if (isStalling) {
      const stallRatio = airspeed / characteristics.stallSpeed;
      liftMultiplier = 0.2 + stallRatio * 0.8;
      controlAuthority = Math.max(0.3, stallRatio);
      
      angularVelocity.x -= dt * 1.5;
    }
    
    let pitchInput = (controls.down ? 1 : 0) - (controls.up ? 1 : 0);
    let rollInput = (controls.right ? 1 : 0) - (controls.left ? 1 : 0);
    let yawInput = (controls.yawRight ? 1 : 0) - (controls.yawLeft ? 1 : 0);
    
    if (autopilotEnabled && waypoints[activeWaypointIndex]) {
      const targetPos = waypoints[activeWaypointIndex].position;
      const dirToWaypoint = targetPos.clone().sub(position).normalize();
      const targetAngleY = Math.atan2(dirToWaypoint.x, dirToWaypoint.z);
      let headingError = targetAngleY - rotation.y;
      if (headingError > Math.PI) headingError -= Math.PI * 2;
      if (headingError < -Math.PI) headingError += Math.PI * 2;
      
      rollInput = THREE.MathUtils.clamp(headingError * 2, -1, 1);
      yawInput = THREE.MathUtils.clamp(headingError, -1, 1);
      
      const altitudeError = targetPos.y - position.y;
      pitchInput = THREE.MathUtils.clamp(altitudeError * 0.01, -1, 1);
      
      throttle = 0.6;
    }
    
    const pitchSpeed = characteristics.pitchSpeed * controlAuthority;
    const rollSpeed = characteristics.rollSpeed * controlAuthority;
    const yawSpeed = characteristics.yawSpeed * controlAuthority;
    
    angularVelocity.x += pitchInput * pitchSpeed * dt;
    angularVelocity.z += rollInput * rollSpeed * dt;
    angularVelocity.y += yawInput * yawSpeed * dt;
    
    angularVelocity.multiplyScalar(0.95);
    
    rotation.x += angularVelocity.x * dt;
    rotation.z += angularVelocity.z * dt;
    rotation.y += angularVelocity.y * dt;
    
    rotation.x = THREE.MathUtils.clamp(rotation.x, -Math.PI / 3, Math.PI / 3);
    rotation.z = THREE.MathUtils.clamp(rotation.z, -Math.PI / 2, Math.PI / 2);
    
    const forwardDir = new THREE.Vector3(0, 0, 1);
    forwardDir.applyEuler(rotation);
    
    const thrustForce = forwardDir.clone().multiplyScalar(throttle * characteristics.thrust);
    
    const gravity = new THREE.Vector3(0, -9.8, 0);
    
    const liftCoefficient = Math.cos(rotation.x) * Math.abs(Math.cos(rotation.z));
    const lift = new THREE.Vector3(0, airspeed * characteristics.liftCoefficient * liftCoefficient * liftMultiplier, 0);
    
    const drag = airVelocity.clone().multiplyScalar(-characteristics.dragCoefficient * airspeed);
    
    const turbulence = new THREE.Vector3(
      (Math.random() - 0.5) * environment.turbulenceIntensity * 1.5,
      (Math.random() - 0.5) * environment.turbulenceIntensity * 0.5,
      (Math.random() - 0.5) * environment.turbulenceIntensity * 1.5
    );
    
    const totalForce = new THREE.Vector3();
    totalForce.add(thrustForce);
    totalForce.add(gravity);
    totalForce.add(lift);
    totalForce.add(drag);
    totalForce.add(turbulence);
    
    velocity.add(totalForce.multiplyScalar(dt));
    
    position.add(velocity.clone().multiplyScalar(dt));
    
    if (position.y < 1 && !aircraft.crashed) {
      position.y = 1;
      velocity.multiplyScalar(0);
      updateAircraft({ crashed: true });
      console.log("Aircraft crashed!");
    }
    
    meshRef.current.position.copy(position);
    meshRef.current.rotation.copy(rotation);
    
    updateAircraft({
      position,
      velocity,
      rotation,
      angularVelocity,
      throttle,
      isStalling,
    });
  });

  return (
    <group ref={meshRef}>
      {aircraftType === "fighter" && <FighterModel />}
      {aircraftType === "cargo" && <CargoModel />}
      {aircraftType === "light" && <LightModel />}
    </group>
  );
}
