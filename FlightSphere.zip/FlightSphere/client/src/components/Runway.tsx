import { useMemo } from "react";
import * as THREE from "three";
import { useTexture } from "@react-three/drei";

export function Runway() {
  const asphaltTexture = useTexture("/textures/asphalt.png");
  
  asphaltTexture.wrapS = asphaltTexture.wrapT = THREE.RepeatWrapping;
  asphaltTexture.repeat.set(2, 20);

  const runwayPosition: [number, number, number] = [500, 0.1, 0];
  const runwaySize: [number, number] = [50, 400];

  const centerlineMarkers = useMemo(() => {
    const markers: Array<[number, number, number]> = [];
    for (let i = -8; i <= 8; i++) {
      markers.push([runwayPosition[0], 0.2, i * 20]);
    }
    return markers;
  }, []);

  const thresholdMarkers = useMemo(() => {
    const markers: Array<[number, number, number]> = [];
    for (let i = -3; i <= 3; i++) {
      markers.push([runwayPosition[0] + i * 6, 0.2, -180]);
      markers.push([runwayPosition[0] + i * 6, 0.2, 180]);
    }
    return markers;
  }, []);

  const approachLights = useMemo(() => {
    const lights: Array<[number, number, number]> = [];
    for (let i = 1; i <= 5; i++) {
      lights.push([runwayPosition[0], 2, -200 - i * 10]);
    }
    return lights;
  }, []);

  return (
    <group>
      <mesh
        receiveShadow
        rotation={[-Math.PI / 2, 0, 0]}
        position={runwayPosition}
      >
        <planeGeometry args={runwaySize} />
        <meshStandardMaterial map={asphaltTexture} color="#2a2a2a" />
      </mesh>

      {centerlineMarkers.map((pos, i) => (
        <mesh
          key={`center-${i}`}
          rotation={[-Math.PI / 2, 0, 0]}
          position={pos}
        >
          <planeGeometry args={[2, 8]} />
          <meshBasicMaterial color="#ffffff" />
        </mesh>
      ))}

      {thresholdMarkers.map((pos, i) => (
        <mesh
          key={`threshold-${i}`}
          rotation={[-Math.PI / 2, 0, 0]}
          position={pos}
        >
          <planeGeometry args={[4, 12]} />
          <meshBasicMaterial color="#ffffff" />
        </mesh>
      ))}

      {approachLights.map((pos, i) => (
        <mesh key={`light-${i}`} position={pos}>
          <boxGeometry args={[1, 4, 1]} />
          <meshBasicMaterial color="#00ff00" />
        </mesh>
      ))}
    </group>
  );
}
