import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useFlight } from "@/lib/stores/useFlight";
import { Text } from "@react-three/drei";

export function Waypoints() {
  const { waypoints, activeWaypointIndex, aircraft, markWaypointReached } = useFlight();

  useFrame(() => {
    const activeWaypoint = waypoints[activeWaypointIndex];
    if (!activeWaypoint || activeWaypoint.reached) return;

    const distance = aircraft.position.distanceTo(activeWaypoint.position);
    if (distance < 30) {
      markWaypointReached(activeWaypointIndex);
    }
  });

  return (
    <group>
      {waypoints.map((waypoint, index) => {
        const isActive = index === activeWaypointIndex;
        const color = waypoint.reached ? "#888888" : (isActive ? "#00ff00" : "#ffaa00");
        
        return (
          <group key={index} position={waypoint.position}>
            <mesh>
              <ringGeometry args={[8, 10, 32]} />
              <meshBasicMaterial
                color={color}
                side={THREE.DoubleSide}
                transparent
                opacity={0.8}
              />
            </mesh>
            
            <mesh position={[0, 0, 0]}>
              <cylinderGeometry args={[0.5, 0.5, 20, 8]} />
              <meshBasicMaterial color={color} />
            </mesh>

            <Text
              position={[0, 15, 0]}
              fontSize={5}
              color={color}
              anchorX="center"
              anchorY="middle"
            >
              {waypoint.name}
            </Text>
          </group>
        );
      })}
    </group>
  );
}
