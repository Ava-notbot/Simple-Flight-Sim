import { useFlight } from "@/lib/stores/useFlight";
import { AIRCRAFT_TYPES } from "@/lib/aircraftTypes";
import * as THREE from "three";

export function HUD() {
  const { aircraft, environment, aircraftType, cameraMode, waypoints, activeWaypointIndex, autopilotEnabled } = useFlight();
  const aircraftInfo = AIRCRAFT_TYPES[aircraftType];
  
  const activeWaypoint = waypoints[activeWaypointIndex];
  const waypointDistance = activeWaypoint ? aircraft.position.distanceTo(activeWaypoint.position).toFixed(0) : "N/A";
  
  const altitude = Math.max(0, aircraft.position.y).toFixed(0);
  const speed = (aircraft.velocity.length() * 3.6).toFixed(0);
  
  const heading = ((THREE.MathUtils.radToDeg(aircraft.rotation.y) + 360) % 360).toFixed(0);
  
  const fuelPercentage = Math.max(0, aircraft.fuel);
  
  const throttlePercentage = (aircraft.throttle * 100).toFixed(0);
  
  const pitch = THREE.MathUtils.radToDeg(aircraft.rotation.x).toFixed(0);
  const roll = THREE.MathUtils.radToDeg(aircraft.rotation.z).toFixed(0);
  
  const windSpeed = (environment.windVelocity.length() * 3.6).toFixed(0);
  const windDirection = ((THREE.MathUtils.radToDeg(Math.atan2(environment.windVelocity.x, environment.windVelocity.z)) + 360) % 360).toFixed(0);
  
  const runwayPosition = new THREE.Vector3(500, 0, 0);
  const lateralOffset = (aircraft.position.x - runwayPosition.x).toFixed(0);
  
  const dx = aircraft.position.x - runwayPosition.x;
  const dz = aircraft.position.z - runwayPosition.z;
  const groundRange = Math.sqrt(dx * dx + dz * dz);
  const distanceToRunway = groundRange.toFixed(0);
  
  const expectedAltitude = groundRange * Math.tan(THREE.MathUtils.degToRad(3));
  const glideSlopeDeviation = (aircraft.position.y - expectedAltitude).toFixed(0);

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      pointerEvents: 'none',
      fontFamily: 'monospace',
      color: '#00ff00',
      fontSize: '14px',
      textShadow: '0 0 10px rgba(0, 255, 0, 0.5)',
    }}>
      <div style={{
        position: 'absolute',
        top: '20px',
        left: '20px',
        background: 'rgba(0, 0, 0, 0.7)',
        padding: '15px',
        borderRadius: '5px',
        border: '2px solid #00ff00',
      }}>
        <div style={{ marginBottom: '8px', fontSize: '16px', fontWeight: 'bold' }}>
          {aircraftInfo.name}
        </div>
        <div style={{ marginBottom: '12px', fontSize: '12px', color: '#888' }}>
          FLIGHT DATA
        </div>
        <div>ALTITUDE: {altitude} m</div>
        <div>SPEED: {speed} km/h</div>
        <div>HEADING: {heading}°</div>
        <div>PITCH: {pitch}°</div>
        <div>ROLL: {roll}°</div>
        {activeWaypoint && (
          <>
            <div style={{ marginTop: '12px', paddingTop: '12px', borderTop: '1px solid #00ff00' }}>
              <div style={{ fontSize: '12px', color: '#888', marginBottom: '5px' }}>NAVIGATION</div>
              <div>{activeWaypoint.name}</div>
              <div>DISTANCE: {waypointDistance} m</div>
              {autopilotEnabled && <div style={{ color: '#ffaa00' }}>AUTOPILOT: ON</div>}
            </div>
          </>
        )}
      </div>

      <div style={{
        position: 'absolute',
        top: '20px',
        right: '20px',
        background: 'rgba(0, 0, 0, 0.7)',
        padding: '15px',
        borderRadius: '5px',
        border: '2px solid #00ff00',
      }}>
        <div style={{ marginBottom: '8px', fontSize: '16px', fontWeight: 'bold' }}>
          SYSTEMS
        </div>
        <div>THROTTLE: {throttlePercentage}%</div>
        <div style={{ marginTop: '10px' }}>
          FUEL: {fuelPercentage.toFixed(1)}%
          <div style={{
            width: '150px',
            height: '20px',
            background: 'rgba(0, 0, 0, 0.5)',
            border: '1px solid #00ff00',
            marginTop: '5px',
            position: 'relative',
          }}>
            <div style={{
              width: `${fuelPercentage}%`,
              height: '100%',
              background: fuelPercentage > 20 ? '#00ff00' : '#ff0000',
              transition: 'width 0.3s ease',
            }} />
          </div>
        </div>
        <div style={{ marginTop: '12px', paddingTop: '12px', borderTop: '1px solid #00ff00' }}>
          <div style={{ fontSize: '12px', color: '#888', marginBottom: '5px' }}>ENVIRONMENT</div>
          <div>WIND: {windSpeed} km/h</div>
          <div>DIRECTION: {windDirection}°</div>
          <div>TURBULENCE: {(environment.turbulenceIntensity * 100).toFixed(0)}%</div>
        </div>
      </div>

      <div style={{
        position: 'absolute',
        bottom: '20px',
        left: '20px',
        background: 'rgba(0, 0, 0, 0.7)',
        padding: '15px',
        borderRadius: '5px',
        border: '2px solid #00ff00',
      }}>
        <div style={{ marginBottom: '8px', fontSize: '16px', fontWeight: 'bold' }}>
          CONTROLS
        </div>
        <div>W/S: Pitch Up/Down</div>
        <div>A/D: Roll Left/Right</div>
        <div>Z/X: Yaw Left/Right</div>
        <div>Q/E: Throttle Down/Up</div>
        <div>C: Change Camera ({cameraMode})</div>
        <div>T: Toggle Autopilot</div>
        <div>R: Reset</div>
      </div>

      <div style={{
        position: 'absolute',
        bottom: '20px',
        right: '20px',
        background: 'rgba(0, 0, 0, 0.7)',
        padding: '15px',
        borderRadius: '5px',
        border: '2px solid #00ff00',
      }}>
        <div style={{ marginBottom: '8px', fontSize: '16px', fontWeight: 'bold' }}>
          APPROACH
        </div>
        <div>DISTANCE: {distanceToRunway} m</div>
        <div>LATERAL: {lateralOffset} m {Math.abs(parseFloat(lateralOffset)) < 25 ? '✓' : '✗'}</div>
        <div style={{ 
          color: Math.abs(parseFloat(glideSlopeDeviation)) < 10 ? '#00ff00' : '#ffaa00'
        }}>
          GLIDE SLOPE: {parseFloat(glideSlopeDeviation) > 0 ? 'HIGH ↓' : 'LOW ↑'} {Math.abs(parseFloat(glideSlopeDeviation))} m
        </div>
      </div>

      {aircraft.crashed && (
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          background: 'rgba(255, 0, 0, 0.9)',
          padding: '40px 60px',
          borderRadius: '10px',
          border: '4px solid #ff0000',
          fontSize: '32px',
          fontWeight: 'bold',
          color: '#ffffff',
          textShadow: '0 0 20px rgba(255, 0, 0, 0.8)',
        }}>
          AIRCRAFT CRASHED!
          <div style={{ fontSize: '16px', marginTop: '20px', textAlign: 'center' }}>
            Press R to restart
          </div>
        </div>
      )}

      {fuelPercentage <= 0 && !aircraft.crashed && (
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          background: 'rgba(255, 165, 0, 0.9)',
          padding: '40px 60px',
          borderRadius: '10px',
          border: '4px solid #ff8800',
          fontSize: '32px',
          fontWeight: 'bold',
          color: '#ffffff',
          textShadow: '0 0 20px rgba(255, 165, 0, 0.8)',
        }}>
          OUT OF FUEL!
        </div>
      )}

      {aircraft.isStalling && !aircraft.crashed && (
        <div style={{
          position: 'absolute',
          top: '30%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          background: 'rgba(255, 100, 0, 0.9)',
          padding: '20px 40px',
          borderRadius: '8px',
          border: '3px solid #ff6600',
          fontSize: '24px',
          fontWeight: 'bold',
          color: '#ffffff',
          textShadow: '0 0 15px rgba(255, 100, 0, 0.8)',
          animation: 'pulse 0.5s infinite',
        }}>
          ⚠️ STALL WARNING ⚠️
          <div style={{ fontSize: '14px', marginTop: '8px', textAlign: 'center' }}>
            Increase throttle and lower nose
          </div>
        </div>
      )}

      <div style={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: '3px',
        height: '30px',
        background: '#00ff00',
      }} />
      <div style={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: '30px',
        height: '3px',
        background: '#00ff00',
      }} />
    </div>
  );
}
