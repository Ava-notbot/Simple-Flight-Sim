import { AIRCRAFT_TYPES } from "@/lib/aircraftTypes";

export function LightModel() {
  const { color, secondaryColor } = AIRCRAFT_TYPES.light;
  
  return (
    <group>
      <mesh castShadow>
        <boxGeometry args={[1.2, 0.6, 3.5]} />
        <meshStandardMaterial color={color} />
      </mesh>
      
      <mesh position={[0, 0.5, -0.5]} castShadow>
        <boxGeometry args={[1, 0.6, 1.5]} />
        <meshStandardMaterial color={color} />
      </mesh>
      
      <mesh position={[-2.5, 0.8, 0.3]} rotation={[0.1, 0, 0]} castShadow>
        <boxGeometry args={[3.5, 0.1, 1]} />
        <meshStandardMaterial color={secondaryColor} />
      </mesh>
      <mesh position={[2.5, 0.8, 0.3]} rotation={[0.1, 0, 0]} castShadow>
        <boxGeometry args={[3.5, 0.1, 1]} />
        <meshStandardMaterial color={secondaryColor} />
      </mesh>
      
      <mesh position={[0, 0.6, -1.5]} castShadow>
        <boxGeometry args={[1.5, 0.6, 0.15]} />
        <meshStandardMaterial color={secondaryColor} />
      </mesh>
      
      <mesh position={[0, 0, 1.9]} castShadow>
        <boxGeometry args={[0.8, 0.5, 0.4]} />
        <meshStandardMaterial color={color} />
      </mesh>
      
      <mesh position={[0, 0, 2.1]} rotation={[Math.PI / 2, 0, 0]} castShadow>
        <coneGeometry args={[0.3, 0.6, 8]} />
        <meshStandardMaterial color={secondaryColor} />
      </mesh>
      
      <mesh position={[-1.5, -0.3, 0.5]} rotation={[0, 0, Math.PI / 2]} castShadow>
        <cylinderGeometry args={[0.15, 0.15, 0.4, 8]} />
        <meshStandardMaterial color="#333" />
      </mesh>
      <mesh position={[1.5, -0.3, 0.5]} rotation={[0, 0, Math.PI / 2]} castShadow>
        <cylinderGeometry args={[0.15, 0.15, 0.4, 8]} />
        <meshStandardMaterial color="#333" />
      </mesh>
      
      <mesh position={[0, -0.3, -0.5]} rotation={[0, 0, Math.PI / 2]} castShadow>
        <cylinderGeometry args={[0.12, 0.12, 0.3, 8]} />
        <meshStandardMaterial color="#333" />
      </mesh>
    </group>
  );
}
