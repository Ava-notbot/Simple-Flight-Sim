import { AIRCRAFT_TYPES } from "@/lib/aircraftTypes";

export function FighterModel() {
  const { color, secondaryColor } = AIRCRAFT_TYPES.fighter;
  
  return (
    <group>
      <mesh castShadow>
        <boxGeometry args={[1.5, 0.4, 5]} />
        <meshStandardMaterial color={color} metalness={0.6} roughness={0.3} />
      </mesh>
      
      <mesh position={[0, 0.4, -0.5]} castShadow>
        <boxGeometry args={[1.2, 0.6, 2.5]} />
        <meshStandardMaterial color={color} metalness={0.6} roughness={0.3} />
      </mesh>
      
      <mesh position={[-2.5, 0, 0]} rotation={[0, 0, 0.05]} castShadow>
        <boxGeometry args={[3.5, 0.08, 1.2]} />
        <meshStandardMaterial color={secondaryColor} metalness={0.5} roughness={0.4} />
      </mesh>
      <mesh position={[2.5, 0, 0]} rotation={[0, 0, -0.05]} castShadow>
        <boxGeometry args={[3.5, 0.08, 1.2]} />
        <meshStandardMaterial color={secondaryColor} metalness={0.5} roughness={0.4} />
      </mesh>
      
      <mesh position={[0, 0.3, -2]} castShadow>
        <boxGeometry args={[1.5, 0.8, 0.15]} />
        <meshStandardMaterial color={secondaryColor} metalness={0.5} roughness={0.4} />
      </mesh>
      
      <mesh position={[0, 0, 2.7]} rotation={[Math.PI / 2, 0, 0]} castShadow>
        <coneGeometry args={[0.5, 1, 8]} />
        <meshStandardMaterial color={color} metalness={0.7} roughness={0.2} />
      </mesh>
      
      <mesh position={[0, 0.8, -1.8]} castShadow>
        <boxGeometry args={[0.15, 1, 0.8]} />
        <meshStandardMaterial color={color} metalness={0.6} roughness={0.3} />
      </mesh>
    </group>
  );
}
