import { AIRCRAFT_TYPES } from "@/lib/aircraftTypes";

export function CargoModel() {
  const { color, secondaryColor } = AIRCRAFT_TYPES.cargo;
  
  return (
    <group>
      <mesh castShadow>
        <boxGeometry args={[2.5, 1.2, 6]} />
        <meshStandardMaterial color={color} />
      </mesh>
      
      <mesh position={[0, 0.8, 0]} castShadow>
        <boxGeometry args={[2, 0.8, 4]} />
        <meshStandardMaterial color={color} />
      </mesh>
      
      <mesh position={[-4, 0.3, 0.5]} rotation={[0, 0, 0.1]} castShadow>
        <boxGeometry args={[5, 0.15, 2]} />
        <meshStandardMaterial color={secondaryColor} />
      </mesh>
      <mesh position={[4, 0.3, 0.5]} rotation={[0, 0, -0.1]} castShadow>
        <boxGeometry args={[5, 0.15, 2]} />
        <meshStandardMaterial color={secondaryColor} />
      </mesh>
      
      <mesh position={[0, 0.5, -2.8]} castShadow>
        <boxGeometry args={[2.2, 1.2, 0.2]} />
        <meshStandardMaterial color={secondaryColor} />
      </mesh>
      
      <mesh position={[0, 0.3, 3.2]} castShadow>
        <boxGeometry args={[2, 1, 0.5]} />
        <meshStandardMaterial color={color} />
      </mesh>
      
      <mesh position={[-2, 0.3, 1.5]} rotation={[0, Math.PI / 4, 0]} castShadow>
        <cylinderGeometry args={[0.5, 0.5, 0.3, 16]} />
        <meshStandardMaterial color={color} />
      </mesh>
      <mesh position={[2, 0.3, 1.5]} rotation={[0, Math.PI / 4, 0]} castShadow>
        <cylinderGeometry args={[0.5, 0.5, 0.3, 16]} />
        <meshStandardMaterial color={color} />
      </mesh>
    </group>
  );
}
