import { useEffect, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { useKeyboardControls } from "@react-three/drei";
import * as THREE from "three";
import { useFlight } from "@/lib/stores/useFlight";

enum Controls {
  forward = 'forward',
  back = 'back',
  left = 'left',
  right = 'right',
  up = 'up',
  down = 'down',
  throttleUp = 'throttleUp',
  throttleDown = 'throttleDown',
  camera = 'camera',
  reset = 'reset',
  autopilot = 'autopilot',
}

export function CameraController() {
  const { camera } = useThree();
  const { aircraft, cameraMode, setCameraMode, resetGame, toggleAutopilot } = useFlight();
  const [subscribe, getKeys] = useKeyboardControls<Controls>();
  const lastCameraPress = useRef(0);
  const lastResetPress = useRef(0);
  const lastAutopilotPress = useRef(0);

  useEffect(() => {
    const unsubscribeCamera = subscribe(
      (state) => state.camera,
      (pressed) => {
        if (pressed) {
          const now = Date.now();
          if (now - lastCameraPress.current > 300) {
            lastCameraPress.current = now;
            const modes: Array<"cockpit" | "chase" | "external"> = ["chase", "cockpit", "external"];
            const currentIndex = modes.indexOf(cameraMode);
            const nextIndex = (currentIndex + 1) % modes.length;
            setCameraMode(modes[nextIndex]);
          }
        }
      }
    );

    const unsubscribeReset = subscribe(
      (state) => state.reset,
      (pressed) => {
        if (pressed) {
          const now = Date.now();
          if (now - lastResetPress.current > 300) {
            lastResetPress.current = now;
            resetGame();
          }
        }
      }
    );

    const unsubscribeAutopilot = subscribe(
      (state) => state.autopilot,
      (pressed) => {
        if (pressed) {
          const now = Date.now();
          if (now - lastAutopilotPress.current > 300) {
            lastAutopilotPress.current = now;
            toggleAutopilot();
          }
        }
      }
    );

    return () => {
      unsubscribeCamera();
      unsubscribeReset();
      unsubscribeAutopilot();
    };
  }, [subscribe, cameraMode, setCameraMode, resetGame, toggleAutopilot]);

  useFrame(() => {
    const pos = aircraft.position;
    const rot = aircraft.rotation;
    
    const targetPosition = new THREE.Vector3();
    const targetLookAt = new THREE.Vector3();

    if (cameraMode === "chase") {
      const offset = new THREE.Vector3(0, 3, -12);
      offset.applyEuler(rot);
      targetPosition.copy(pos).add(offset);
      
      const lookOffset = new THREE.Vector3(0, 0, 10);
      lookOffset.applyEuler(rot);
      targetLookAt.copy(pos).add(lookOffset);
    } else if (cameraMode === "cockpit") {
      const offset = new THREE.Vector3(0, 1, 1);
      offset.applyEuler(rot);
      targetPosition.copy(pos).add(offset);
      
      const lookOffset = new THREE.Vector3(0, 0, 20);
      lookOffset.applyEuler(rot);
      targetLookAt.copy(pos).add(lookOffset);
    } else if (cameraMode === "external") {
      const angle = Date.now() * 0.0002;
      const radius = 30;
      targetPosition.set(
        pos.x + Math.sin(angle) * radius,
        pos.y + 15,
        pos.z + Math.cos(angle) * radius
      );
      targetLookAt.copy(pos);
    }

    camera.position.lerp(targetPosition, 0.1);
    
    const currentLookAt = new THREE.Vector3(0, 0, -1);
    currentLookAt.applyQuaternion(camera.quaternion);
    currentLookAt.add(camera.position);
    currentLookAt.lerp(targetLookAt, 0.1);
    
    camera.lookAt(currentLookAt);
  });

  return null;
}
