import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useState } from "react";
import { KeyboardControls } from "@react-three/drei";
import "@fontsource/inter";
import { Aircraft } from "./components/Aircraft";
import { Environment } from "./components/Environment";
import { CameraController } from "./components/CameraController";
import { HUD } from "./components/HUD";
import { AircraftSelection } from "./components/AircraftSelection";
import { useFlight } from "./lib/stores/useFlight";

enum Controls {
  forward = 'forward',
  back = 'back',
  left = 'left',
  right = 'right',
  up = 'up',
  down = 'down',
  yawLeft = 'yawLeft',
  yawRight = 'yawRight',
  throttleUp = 'throttleUp',
  throttleDown = 'throttleDown',
  camera = 'camera',
  reset = 'reset',
  autopilot = 'autopilot',
}

const controls = [
  { name: Controls.up, keys: ["KeyW", "ArrowUp"] },
  { name: Controls.down, keys: ["KeyS", "ArrowDown"] },
  { name: Controls.left, keys: ["KeyA", "ArrowLeft"] },
  { name: Controls.right, keys: ["KeyD", "ArrowRight"] },
  { name: Controls.yawLeft, keys: ["KeyZ"] },
  { name: Controls.yawRight, keys: ["KeyX"] },
  { name: Controls.throttleUp, keys: ["KeyE"] },
  { name: Controls.throttleDown, keys: ["KeyQ"] },
  { name: Controls.camera, keys: ["KeyC"] },
  { name: Controls.reset, keys: ["KeyR"] },
  { name: Controls.autopilot, keys: ["KeyT"] },
];

function App() {
  const [showCanvas, setShowCanvas] = useState(false);
  const { gameStarted, showAircraftSelection } = useFlight();

  useEffect(() => {
    setShowCanvas(true);
    console.log("Flight Simulator initialized");
  }, []);

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
      {showAircraftSelection && <AircraftSelection />}
      
      {showCanvas && gameStarted && !showAircraftSelection && (
        <KeyboardControls map={controls}>
          <Canvas
            shadows
            camera={{
              position: [0, 60, -20],
              fov: 60,
              near: 0.1,
              far: 2000
            }}
            gl={{
              antialias: true,
              powerPreference: "high-performance"
            }}
          >
            <ambientLight intensity={0.4} />
            <directionalLight
              position={[100, 100, 50]}
              intensity={1}
              castShadow
              shadow-mapSize-width={2048}
              shadow-mapSize-height={2048}
              shadow-camera-far={500}
              shadow-camera-left={-100}
              shadow-camera-right={100}
              shadow-camera-top={100}
              shadow-camera-bottom={-100}
            />

            <Suspense fallback={null}>
              <Environment />
              <Aircraft />
              <CameraController />
            </Suspense>
          </Canvas>
          <HUD />
        </KeyboardControls>
      )}
    </div>
  );
}

export default App;
